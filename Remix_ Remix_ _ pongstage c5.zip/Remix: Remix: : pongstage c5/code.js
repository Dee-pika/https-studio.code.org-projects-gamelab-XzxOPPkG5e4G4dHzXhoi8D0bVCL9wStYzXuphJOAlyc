var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["20d5c849-4793-4188-94e0-a41666395092","f946cdcc-9135-4631-813d-7d9070baf33f","6c686140-fc04-4437-84b2-6a1c88b3620d","19bced82-6c73-4990-92a4-71218e77ca3d"],"propsByKey":{"20d5c849-4793-4188-94e0-a41666395092":{"name":"beachball_1","sourceUrl":null,"frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":12,"version":"Ec7AiDyV1G6.AgugED2wU0wj_vTiahpx","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/20d5c849-4793-4188-94e0-a41666395092.png"},"f946cdcc-9135-4631-813d-7d9070baf33f":{"name":"soccer_field_1","sourceUrl":"assets/api/v1/animation-library/gamelab/J6AoCEQiDKlKsdVff_tiZnDVueArBO2V/category_backgrounds/soccer_field.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"J6AoCEQiDKlKsdVff_tiZnDVueArBO2V","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/J6AoCEQiDKlKsdVff_tiZnDVueArBO2V/category_backgrounds/soccer_field.png"},"6c686140-fc04-4437-84b2-6a1c88b3620d":{"name":"paddle2","sourceUrl":null,"frameSize":{"x":640,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":".CRM5FuVuDVmfUT5v5E0kbxIJrb5SpSQ","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":640,"y":400},"rootRelativePath":"assets/6c686140-fc04-4437-84b2-6a1c88b3620d.png"},"19bced82-6c73-4990-92a4-71218e77ca3d":{"name":"paddle1","sourceUrl":"assets/api/v1/animation-library/gamelab/nWr2zMHCUeCVRl5vawHBxi9C0Pq6bgvZ/category_robots/robot_27.png","frameSize":{"x":374,"y":396},"frameCount":1,"looping":true,"frameDelay":2,"version":"nWr2zMHCUeCVRl5vawHBxi9C0Pq6bgvZ","categories":["robots"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":374,"y":396},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nWr2zMHCUeCVRl5vawHBxi9C0Pq6bgvZ/category_robots/robot_27.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var ball = createSprite(200, 200, 20, 20);
ball.shapeColor = "red";
var paddle1 = createSprite(10, 200, 15, 100);
paddle1.setAnimation("paddle1");
var paddle2 = createSprite(400, 200, 15, 100);
paddle2.setAnimation("paddle2");
ball.rotationSpeed = 100;
paddle2.scale = 0.3;
paddle1.scale = 0.2;
ball.setAnimation("beachball_1");
ball.scale = 0.1;
function linedraw() {
  for (var num = 0; num < 400; num+=30) {
    line(200, num, 200, num+20);
  }
}
function draw() {
  
}
function bounce_objects() {
  ball.bounceOff(paddle1);
  ball.bounceOff(paddle2);
  ball.bounceOff(bottomEdge);
  paddle2.bounceOff(edges);
  ball.bounceOff(topEdge);
  ball.bounceOff(leftEdge);
  paddle2.bounceOff(edges);
  paddle1.bounceOff(edges);
}
function draw() {
  background("violet");
  createEdgeSprites();
  linedraw();
  if (keyDown("up")) {
    paddle2.y = paddle2.y - 10;
  }
  if (keyDown("down")) {
    paddle2.y = paddle2.y + 10;
  }
  if (ball.isTouching(paddle1) || ball.isTouching(paddle2)) {
    playSound("assets/category_bell/choose_background.mp3", false);
  }
  if (keyDown("space")) {
    ball.velocityX = 5;
    ball.velocityY = -5;
  }
  paddle1.y = ball.y;
  bounce_objects();
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
